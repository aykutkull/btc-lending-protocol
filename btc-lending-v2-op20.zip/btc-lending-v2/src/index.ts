export { BTCLendingProtocol as ContractClass } from './contracts/BTCLendingProtocol';
